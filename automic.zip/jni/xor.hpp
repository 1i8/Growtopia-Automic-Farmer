#pragma once
#include <string>
#include <random>

namespace Xor {
    std::string encDec(const char* enc,  int ln, bool mode = false);
}