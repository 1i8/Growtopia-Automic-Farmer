# Android Hooking Template
This is a simple template for the usage of Cydia Substrate.

### Installation:
* Download Android NDK, Revision 16b from: https://developer.android.com/ndk/downloads/older_releases
* Open compile.bat & paste your ndk-build path location in the first line. (remove mine)
* Download this github files somewhere to your PC.


A thread on a forum with mod menu source https://guidedhacking.com/threads/substrate-hooking-template-mod-menu.14674/#post-89655


Also consider joining my Discord Server https://discord.gg/bmRCJQ3
